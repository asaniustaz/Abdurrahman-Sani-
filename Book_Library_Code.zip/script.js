
// Arabic book categories
const categories = {
  "علوم القرآن": [],
  "علوم الحديث": [],
  "التوحيد والعقيدة": [],
  "الفقه وأصوله": [],
  "السلوك": [],
  "اللغة العربية": [],
  "الرسائل": [],
  "كتب ابن تيمية": [],
  "كتب ابن حجر": [],
  "كتب ابن القيم": [],
  "كتب ابن الجوزي": [],
  "كتب ابن رجب": [],
  "كتب الألباني": [],
  "كتب القرضاوي": [],
  "كتب النووي": [],
};

function showLogin(role) {
  document.getElementById("login-section").classList.remove("hidden");
  document.getElementById("login-title").textContent = `Login as ${role}`;
  document.getElementById("login-form").dataset.role = role;
}

function handleLogin(event) {
  event.preventDefault();
  const role = event.target.dataset.role;
  const password = document.getElementById("password").value;

  if (role === "admin" && password === "admin123") {
    document.getElementById("admin-section").classList.remove("hidden");
    document.getElementById("login-section").classList.add("hidden");
  } else if (role === "visitor" && password === "visitor123") {
    document.getElementById("visitor-section").classList.remove("hidden");
    document.getElementById("login-section").classList.add("hidden");
    displayCategories();
  } else {
    alert("Incorrect password");
  }
  document.getElementById("password").value = "";
}

function addBook(event) {
  event.preventDefault();
  const bookName = document.getElementById("book-name").value;
  const bookLink = document.getElementById("book-link").value;
  const bookCategory = document.getElementById("book-category").value;

  if (categories[bookCategory]) {
    categories[bookCategory].push({ name: bookName, link: bookLink });
    document.getElementById("book-name").value = "";
    document.getElementById("book-link").value = "";
    document.getElementById("book-category").value = "";
    document.getElementById("admin-message").textContent = "Book added successfully!";
  }
}

function displayCategories() {
  const categoriesDiv = document.getElementById("categories");
  categoriesDiv.innerHTML = "";

  for (const [category, books] of Object.entries(categories)) {
    const categoryDiv = document.createElement("div");
    categoryDiv.classList.add("category");

    const categoryTitle = document.createElement("h3");
    categoryTitle.textContent = category;
    categoryDiv.appendChild(categoryTitle);

    const bookList = document.createElement("ul");
    books.forEach((book) => {
      const listItem = document.createElement("li");
      const link = document.createElement("a");
      link.textContent = book.name;
      link.href = book.link;
      link.target = "_blank";
      listItem.appendChild(link);
      bookList.appendChild(listItem);
    });

    categoryDiv.appendChild(bookList);
    categoriesDiv.appendChild(categoryDiv);
  }
}
